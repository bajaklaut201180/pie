-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2017 at 07:59 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deliverpie`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `privileges_id` int(11) NOT NULL,
  `username_admin` varchar(50) NOT NULL,
  `password_admin` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `unique_id`, `privileges_id`, `username_admin`, `password_admin`, `flag`) VALUES
(1, 1, 2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1),
(2, 2, 1, 'superadmin', '17c4520f6cfd1ab53d8745e84681eb49', 1);

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `article_name` varchar(50) NOT NULL,
  `article_head` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `article_section` int(11) NOT NULL,
  `article_content` text NOT NULL,
  `article_image` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `banner_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `banner_name` varchar(50) NOT NULL,
  `banner_caption` varchar(50) NOT NULL,
  `banner_image` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallery_category`
--

DROP TABLE IF EXISTS `gallery_category`;
CREATE TABLE `gallery_category` (
  `gallery_category_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `gallery_category_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `gallery_category_type` tinyint(4) NOT NULL,
  `gallery_category_parent` tinyint(4) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `item_category` int(11) NOT NULL,
  `item_image` varchar(50) NOT NULL,
  `item_content` text NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `log_id` int(11) NOT NULL,
  `log_admin_id` int(11) NOT NULL,
  `log_action` varchar(250) NOT NULL,
  `log_db` varchar(250) NOT NULL,
  `log_value` int(11) NOT NULL,
  `log_name` varchar(250) NOT NULL,
  `log_desc` varchar(250) NOT NULL,
  `log_ip` varchar(20) NOT NULL,
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `message_id` int(11) NOT NULL,
  `message_name` varchar(250) NOT NULL,
  `message_address` text NOT NULL,
  `message_email` varchar(250) NOT NULL,
  `message_phone` varchar(250) NOT NULL,
  `message_company` varchar(250) NOT NULL,
  `message_subject` varchar(250) NOT NULL,
  `message_content` text NOT NULL,
  `message_reply` text NOT NULL,
  `message_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `flag` tinyint(4) NOT NULL DEFAULT '2',
  `replied` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `news_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `news_type` varchar(50) NOT NULL,
  `news_image` varchar(50) NOT NULL,
  `news_content` varchar(50) NOT NULL,
  `news_start` datetime NOT NULL,
  `news_end` datetime NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE `photo` (
  `photo_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `photo_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `photo_category` int(11) NOT NULL,
  `photo_image` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `privileges`
--

DROP TABLE IF EXISTS `privileges`;
CREATE TABLE `privileges` (
  `privileges_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `privileges_name` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privileges`
--

INSERT INTO `privileges` (`privileges_id`, `unique_id`, `privileges_name`, `flag`) VALUES
(1, 1, 'Super Admin', 1),
(2, 2, 'Administrator', 1),
(3, 3, 'Special', 1);

-- --------------------------------------------------------

--
-- Table structure for table `privileges_status`
--

DROP TABLE IF EXISTS `privileges_status`;
CREATE TABLE `privileges_status` (
  `privileges_status_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `privileges_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `read` tinyint(4) NOT NULL,
  `update` tinyint(4) NOT NULL,
  `delete` tinyint(4) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `product_category_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `product_category_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `product_category_parent` int(11) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `section_parent` tinyint(4) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `unique_id`, `section_name`, `section_parent`, `flag`) VALUES
(1, 1, 'Setting', 0, 1),
(2, 2, 'Content', 0, 1),
(3, 3, 'Section', 1, 1),
(4, 4, 'Banner', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL,
  `setting_address` varchar(50) NOT NULL,
  `setting_country` varchar(50) NOT NULL,
  `setting_city` varchar(50) NOT NULL,
  `setting_postcode` varchar(50) NOT NULL,
  `setting_phone` varchar(50) NOT NULL,
  `setting_mobile` varchar(50) NOT NULL,
  `setting_email` varchar(50) NOT NULL,
  `setting_facebook` varchar(50) NOT NULL,
  `setting_twitter` varchar(50) NOT NULL,
  `setting_google_map` varchar(50) NOT NULL,
  `setting_google_analytics` varchar(50) NOT NULL,
  `setting_web_title` varchar(50) NOT NULL,
  `setting_web_motto` varchar(50) NOT NULL,
  `setting_web_logo` varchar(50) NOT NULL,
  `setting_favicon` varchar(50) NOT NULL,
  `setting_meta_desc` varchar(50) NOT NULL,
  `setting_meta_key` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`setting_id`, `setting_name`, `setting_address`, `setting_country`, `setting_city`, `setting_postcode`, `setting_phone`, `setting_mobile`, `setting_email`, `setting_facebook`, `setting_twitter`, `setting_google_map`, `setting_google_analytics`, `setting_web_title`, `setting_web_motto`, `setting_web_logo`, `setting_favicon`, `setting_meta_desc`, `setting_meta_key`, `flag`) VALUES
(1, 'ycms company', 'testing - testing', 'indonesia', 'bogor', '123456', '1234567890', '1234 5678 9', 'test@info.com', 'facebook accounts', 'twitter accounts', '', '', 'ycms', 'test', 'logo.png', 'Y-logo.ico', 'tets test tes', 'test tes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
CREATE TABLE `video` (
  `video_id` int(11) NOT NULL,
  `unique_id` int(11) NOT NULL,
  `video_name` varchar(50) NOT NULL,
  `seo_url` varchar(50) NOT NULL,
  `video_category` int(11) NOT NULL,
  `video_link` varchar(50) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`article_id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `gallery_category`
--
ALTER TABLE `gallery_category`
  ADD PRIMARY KEY (`gallery_category_id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`photo_id`);

--
-- Indexes for table `privileges`
--
ALTER TABLE `privileges`
  ADD PRIMARY KEY (`privileges_id`);

--
-- Indexes for table `privileges_status`
--
ALTER TABLE `privileges_status`
  ADD PRIMARY KEY (`privileges_status_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`product_category_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`video_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gallery_category`
--
ALTER TABLE `gallery_category`
  MODIFY `gallery_category_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `photo`
--
ALTER TABLE `photo`
  MODIFY `photo_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `privileges`
--
ALTER TABLE `privileges`
  MODIFY `privileges_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `privileges_status`
--
ALTER TABLE `privileges_status`
  MODIFY `privileges_status_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `product_category_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `video_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
